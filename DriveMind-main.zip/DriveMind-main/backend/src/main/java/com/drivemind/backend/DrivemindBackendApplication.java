package com.drivemind.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DrivemindBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(DrivemindBackendApplication.class, args);
	}

}
